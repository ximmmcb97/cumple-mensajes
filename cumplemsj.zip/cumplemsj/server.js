const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'messages.json');

app.use(express.json());
app.use(express.static('public'));

app.get('/messages', (req, res) => {
  const data = fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE)) : [];
  res.json(data);
});

app.post('/messages', (req, res) => {
  const { name, message } = req.body;
  if (!name || !message) return res.status(400).send('Faltan datos');

  const messages = fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE)) : [];
  messages.push({ name, message, date: new Date() });

  fs.writeFileSync(DATA_FILE, JSON.stringify(messages, null, 2));
  res.status(201).send('Mensaje guardado');
});

app.listen(PORT, () => console.log(`Servidor en http://localhost:${PORT}`));
