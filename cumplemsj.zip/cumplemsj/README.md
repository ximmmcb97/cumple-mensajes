# 🎂 App de Mensajes de Cumpleaños

Formulario web para dejar y ver mensajes de cumpleaños como cartas.

## Cómo correr localmente

```bash
npm install
npm start
